// Endpoint Project
axios.defaults.baseURL = 'http://localhost:8000'

// - Route: LihatUser
const LihatUser = {
  template: '#lihat-user',

// Guard beforeRouteEnter() selalu dipanggil sebelum route diakses.
  beforeRouteEnter(to, from, next) {
    next(vm => {
      vm.$root.user = { nama: '', email: '', alamat: '' }
    })
  },
}
// - Route: TambahUser
const TambahUser = {
  template: '#tambah-user',
}
// - Route: UbahUser
const UbahUser = {
  template: '#ubah-user',

// agar data user bisa terisi sesuai dengan id user yang disertakan
  beforeRouteEnter(to, from, next) {
    next(vm => {
      vm.$root.ambilUser(to.params.id_user)
    })
  },
}


// Mulai Vue App
const app = new Vue({
  el: '#app',

  data: {
    users: [],
    user: { nama: '', email: '', alamat: '' },
    message: '',
  },

  // Routing memakai Vue Router
  router: new VueRouter({
    routes: [
      { path: '/', component: LihatUser, name: 'lihat-user' },
      { path: '/user/tambah', component: TambahUser, name: 'tambah-user' },
      { path: '/user/:id_user/ubah', component: UbahUser, name: 'ubah-user' },
    ]
  }),

  methods: {
    // Ambil semua data user dari API server
    ambilSemuaUser() {
      axios.get('/user.php')
        .then(response => {
          this.users = response.data
      })
    },

    // Ambil data user berdasarkan ID
    ambilUser(userId) {
      this.user = this.users.find(function (item) { return item.id == userId })
    },

    // Tambahkan user baru ke API server
    tambahUser() {
      axios.post('/user.php', this.user)
        .then(response => {
          // Set pesan sesuai respon dari API server
          this.message = response.data.message

          // Tambahkan data user yang baru ke this.users
          this.users.push(this.user)

          // Redirect kembali ke lihat-user
          this.$router.push({ name: 'lihat-user' })
        })
    },

    // Tambahkan user baru ke API server
    ubahUser(userId) {
      axios.patch('/user.php?id=' + userId, this.user)
        .then(response => {
          // Set pesan sesuai respon dari API server
          this.message = response.data.message
          var i = this.users.findIndex(function (item) { return item.id == userId })
          this.users.splice(i, 1, this.user)
          this.$router.push({ name: 'lihat-user' })
        })
    },

    // Tambahkan user baru ke API server
    hapusUser(userId) {
      if (confirm('Yakin ingin menghapus data user ini?')) {
        axios.delete('/user.php?id=' + userId)
          .then(response => {
            this.message = response.data.message
            var i = this.users.findIndex(function (item) { return item.id == userId })
            this.users.splice(i, 1)
          })
      }
    }
  },

  created() {
    this.ambilSemuaUser()
  }
})
