## Cara Pakai
1. [Download zip](https://github.com/Raryadi/tugas_akhir) dan ekstrak ke folder yang Anda inginkan.
2. Buat database baru dan import `vue-php-native.sql` ke database.
3. Buka `db.php` dan sesuaikan konfigurasi database dengan server lokal Anda.
3. Buka `app.js` dan sesuaikan `axios.defaults.baseURL` ke URL proyek di server lokal Anda.
4. Buka aplikasi via web browser

## Lisensi
Copyright © 2023 Riki Aryadi.
